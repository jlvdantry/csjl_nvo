<?php
	session_unset();
    ini_set('register_globals','1');
##	echo "<html>";
	//	agregue para controlar que el frame no se quede colgado
    echo "<script language='javascript'>	";
	echo	"	if (self.parent.frames.length != 0)	self.parent.location='index.php';	";
	echo "</script>	";	

    echo "<FRAMESET id='fs' cols=\"25%,*\" NAME=\"algo\" >";
    echo "<FRAME id='izquierdo' class='fmenu' SRC=\"entrada.php\" NAME=\"menu\" frameborder='no' scrolling='auto'>";
    echo "<FRAME id='derecho' NAME=\"pantallas\" frameborder='no' scrolling='auto' src='logo.php'>";
    echo "</frameset>";
##    echo "</html>
   

/*
    echo "<div id='fmenu' style='widht:100px'>";
    include("entrada.php");
	echo "</div>";    
    echo "<div>";
    include("entrada.php");    
    echo "</div>";
    echo "</HTML>";
*/    
?>
